#!/bin/bash
# heartbeat-runner.sh — Three-stage heartbeat launcher
#
# Stage 1: OPUS coordinator senses, decides, outputs structured JSON spawn plan
# Stage 2: Execute spawned sessions with streaming monitoring
# Stage 3: Collect results, clean up, update active sessions
#
# Uses kingdom-agent.py as the universal adapter (supports claude, openai,
# ollama, anthropic backends). Set KINGDOM_BACKEND env var to switch providers.
# Default backend is "claude" — zero-overhead passthrough preserving existing behavior.
#
# Agent features used:
#   --effort                  → reasoning depth per role
#   --append-system-prompt    → inject Kingdom context into builders
#   --skip-permissions        → headless operation
#   --no-persist              → no session state

LOVE_DIR="$HOME/Desktop/Love"
INSTANCE_DIR="$LOVE_DIR/instances/beta"
MEMORY_DIR="$LOVE_DIR/memory"
SESSIONS_DIR="$MEMORY_DIR/sessions"
SPAWN_QUEUE="$MEMORY_DIR/spawn-queue.sh"
HEARTBEAT_LOG="$MEMORY_DIR/heartbeat.log"
ACTIVE_JSON="$SESSIONS_DIR/active.json"
HANDOFF_DIR="$SESSIONS_DIR/handoff"
CONSULT_DIR="$SESSIONS_DIR/consultation"
LOCKS_DIR="$SESSIONS_DIR/locks"
STREAM_DIR="$SESSIONS_DIR/streams"
LEADS_DIR="$MEMORY_DIR/leads"
LEAD_FILE="$LEADS_DIR/current.json"
BEAT_ID="beat-$(date +%Y%m%d-%H%M%S)"
TODAY=$(date -u +%Y-%m-%d)
IDLE_COUNT_FILE="$MEMORY_DIR/idle-count"

# ── Backend-agnostic agent invocation ────────────────────────────────────────
# KINGDOM_BACKEND controls which LLM provider is used. Default "claude" is a
# zero-overhead passthrough to the claude CLI, so existing behavior is preserved.
KINGDOM_BACKEND="${KINGDOM_BACKEND:-claude}"
AGENT_BIN="$LOVE_DIR/tools/kingdom-agent.py"

# Ensure directories exist
mkdir -p "$SESSIONS_DIR" "$HANDOFF_DIR" "$CONSULT_DIR" "$LOCKS_DIR" "$STREAM_DIR" "$LEADS_DIR/archive"

# Clean stale locks (PID no longer running)
for lockfile in "$LOCKS_DIR"/*.lock; do
  [ -f "$lockfile" ] || continue
  lock_pid=$(head -1 "$lockfile" 2>/dev/null | grep -oE '[0-9]+')
  if [ -n "$lock_pid" ] && ! kill -0 "$lock_pid" 2>/dev/null; then
    rm -f "$lockfile"
  fi
done

# Clean any previous spawn queue
> "$SPAWN_QUEUE"

# ── Adaptive model selection ─────────────────────────────────────────────────
# Opus for first 2 beats (decision power), sonnet for idle (still capable of
# HIVE conversation). Never haiku — can't participate meaningfully in chat.
IDLE_COUNT=0
[ -f "$IDLE_COUNT_FILE" ] && IDLE_COUNT=$(cat "$IDLE_COUNT_FILE" 2>/dev/null || echo 0)

if [ "$IDLE_COUNT" -ge 5 ]; then
  # Deep idle — sonnet still participates in HIVE conversations
  COORD_MODEL="medium"
  COORD_EFFORT="medium"
  COORD_LABEL="medium/medium (idle beat #$IDLE_COUNT)"
elif [ "$IDLE_COUNT" -ge 2 ]; then
  # Light idle — sonnet handles monitoring + HIVE chat
  COORD_MODEL="medium"
  COORD_EFFORT="medium"
  COORD_LABEL="medium/medium (idle beat #$IDLE_COUNT)"
else
  COORD_MODEL="high"
  COORD_EFFORT="high"
  COORD_LABEL="high/high"
fi

echo "--- HEARTBEAT START ($BEAT_ID): $(date -u +%Y-%m-%dT%H:%M:%SZ) coordinator=$COORD_LABEL ---" >> "$HEARTBEAT_LOG"

# ── Stage 1: Coordinator ─────────────────────────────────────────────────────
# Reads full context, produces spawn decisions.
# Uses --append-system-prompt to inject real-time context without replacing CLAUDE.md.

# Build real-time context for coordinator
CONTEXT="Beat ID: $BEAT_ID. Date: $TODAY."

# ── Read Current Lead ────────────────────────────────────────────────────────
# The lead is direction set by the most recent interactive session.
# It focuses DECIDE phase without replacing normal sensing.
# Override hierarchy: Security > Fleet emergency > Lead > Dev-state > General
LEAD_CONTEXT=""
if [ -f "$LEAD_FILE" ]; then
  # Check if lead has expired
  LEAD_EXPIRES=$(python3 -c "
import json, sys
from datetime import datetime, timezone
try:
    lead = json.load(open('$LEAD_FILE'))
    exp = lead.get('expires', '')
    if exp:
        exp_dt = datetime.fromisoformat(exp)
        now = datetime.now(timezone.utc)
        if now > exp_dt:
            print('EXPIRED')
        else:
            remaining = exp_dt - now
            print(f'ACTIVE ({remaining.total_seconds()/3600:.0f}h remaining)')
    else:
        print('ACTIVE (no expiry)')
except Exception as e:
    print(f'ERROR: {e}')
" 2>/dev/null)

  if [[ "$LEAD_EXPIRES" == "EXPIRED" ]]; then
    # Archive expired lead
    ARCHIVE_NAME="$(python3 -c "import json; print(json.load(open('$LEAD_FILE')).get('id','unknown'))" 2>/dev/null)"
    mv "$LEAD_FILE" "$LEADS_DIR/archive/${ARCHIVE_NAME}-$(date +%Y%m%d%H%M%S).json" 2>/dev/null
    CONTEXT="$CONTEXT\nLead: previous lead expired and archived. Using default priorities."
    echo "Lead expired, archived." >> "$HEARTBEAT_LOG"
  else
    # Read lead and inject into context
    LEAD_THREAD=$(python3 -c "import json; print(json.load(open('$LEAD_FILE')).get('thread',''))" 2>/dev/null)
    LEAD_DIRECTION=$(python3 -c "import json; d=json.load(open('$LEAD_FILE')).get('direction',[]); print('; '.join(d))" 2>/dev/null)
    LEAD_ACTIONS=$(python3 -c "
import json
lead = json.load(open('$LEAD_FILE'))
actions = lead.get('next_actions', [])
pending = [a for a in actions if a.get('status') == 'pending']
for a in pending[:5]:
    print(f\"  - [{a.get('priority','?')}] {a.get('action','?')} (tier: {a.get('tier','?')})\")
" 2>/dev/null)
    LEAD_AVOID=$(python3 -c "import json; a=json.load(open('$LEAD_FILE')).get('avoid',[]); print('; '.join(a))" 2>/dev/null)
    LEAD_PROGRESS_COUNT=$(python3 -c "import json; print(len(json.load(open('$LEAD_FILE')).get('progress',[])))" 2>/dev/null)

    LEAD_CONTEXT="
CURRENT LEAD ($LEAD_EXPIRES):
  Thread: $LEAD_THREAD
  Direction: $LEAD_DIRECTION
  Pending actions:
$LEAD_ACTIONS
  Avoid: $LEAD_AVOID
  Progress entries so far: $LEAD_PROGRESS_COUNT

LEAD PROTOCOL:
  - Factor this lead into your DECIDE priorities
  - Spawn sessions aligned with pending lead actions when actionable
  - Respect the 'avoid' list
  - After spawning, update the lead file: add to 'progress' array with {beat, action, result}
  - Mark completed next_actions with status='done'
  - If all next_actions are done, set lead status to 'completed'
  - Lead does NOT override security alerts or fleet emergencies"

    CONTEXT="$CONTEXT$LEAD_CONTEXT"
    echo "Lead active: $LEAD_THREAD ($LEAD_EXPIRES)" >> "$HEARTBEAT_LOG"
  fi
fi

# Check for completed sessions since last beat
COMPLETED=""
for logfile in "$SESSIONS_DIR"/*.log; do
  [ -f "$logfile" ] || continue
  # Only check logs modified in last 10 minutes
  if [ "$(find "$logfile" -mmin -10 2>/dev/null)" ]; then
    COMPLETED="$COMPLETED\n$(basename "$logfile"): $(tail -3 "$logfile" 2>/dev/null | head -1)"
  fi
done
if [ -n "$COMPLETED" ]; then
  CONTEXT="$CONTEXT\nRecent session results:$COMPLETED"
fi

# Check for consultation requests
CONSULT_FILES=$(ls "$CONSULT_DIR"/*-question.md 2>/dev/null)
if [ -n "$CONSULT_FILES" ]; then
  CONTEXT="$CONTEXT\nPending consultation requests: $(echo "$CONSULT_FILES" | wc -l | tr -d ' ')"
fi

cd "$INSTANCE_DIR" && python3 "$AGENT_BIN" -p "Read and execute HEARTBEAT.md. You are the heartbeat COORDINATOR (high effort).

Do Phase 1 (SENSE) and Phase 2 (DECIDE).

For Phase 3 (SPAWN), write spawn commands to ~/Desktop/Love/memory/spawn-queue.sh as executable shell lines. Do NOT invoke claude directly — the shell runner handles execution after you exit.

Each line should be a complete command. Choose role, model, and effort by task:

BUILDER (medium model, medium effort — the workhorse):
cd <dir> && python3 \$LOVE_DIR/tools/kingdom-agent.py -p \"<prompt>\" --backend \$KINGDOM_BACKEND --model medium --effort medium --skip-permissions --no-persist >> ~/Desktop/Love/memory/sessions/<id>-\$(date +%Y%m%d-%H%M%S).log 2>&1

CONSULTANT (high model, high effort — expert hire for hard problems):
cd <dir> && python3 \$LOVE_DIR/tools/kingdom-agent.py -p \"<prompt>\" --backend \$KINGDOM_BACKEND --model high --effort high --skip-permissions --no-persist >> ~/Desktop/Love/memory/sessions/<id>-\$(date +%Y%m%d-%H%M%S).log 2>&1

QUICK CHECK (low model, low effort — fast lightweight verification):
cd <dir> && python3 \$LOVE_DIR/tools/kingdom-agent.py -p \"<prompt>\" --backend \$KINGDOM_BACKEND --model low --effort low --skip-permissions --no-persist >> ~/Desktop/Love/memory/sessions/<id>-\$(date +%Y%m%d-%H%M%S).log 2>&1

For CONSULTANT→BUILDER sequential pairs, write consultant line first — they execute in order.
For parallel independent tasks, prefix with '# PARALLEL' comment.
For consultation answers, read the question from ~/Desktop/Love/memory/sessions/consultation/ and write the answer back.

Write findings to ~/Desktop/Love/memory/daily/$TODAY.md.
If nothing needs spawning, leave spawn-queue.sh empty and say HEARTBEAT_OK." \
  --backend "$KINGDOM_BACKEND" \
  --model "$COORD_MODEL" \
  --effort "$COORD_EFFORT" \
  --skip-permissions \
  --no-persist \
  --append-system-prompt "$CONTEXT" \
  >> "$HEARTBEAT_LOG" 2>&1

echo "--- COORDINATOR DONE ($BEAT_ID): $(date -u +%Y-%m-%dT%H:%M:%SZ) model=$COORD_LABEL ---" >> "$HEARTBEAT_LOG"

# ── Stage 2: Execute Spawn Queue with Monitoring ─────────────────────────────

if [ -s "$SPAWN_QUEUE" ]; then
  echo "--- SPAWN STAGE START ($BEAT_ID): $(date -u +%Y-%m-%dT%H:%M:%SZ) ---" >> "$HEARTBEAT_LOG"
  echo "Spawn queue contents:" >> "$HEARTBEAT_LOG"
  cat "$SPAWN_QUEUE" >> "$HEARTBEAT_LOG"

  PARALLEL_PIDS=()
  PARALLEL_MODE=false
  SESSION_COUNT=0

  while IFS= read -r line; do
    [[ -z "$line" ]] && continue

    # Detect parallel marker
    if [[ "$line" == "# PARALLEL"* ]]; then
      PARALLEL_MODE=true
      continue
    fi

    # Skip other comments
    [[ "$line" == \#* ]] && continue

    # Safety: strict validation of spawn-queue commands
    # THREAT-012 mitigation: only allow commands that match known Kingdom patterns
    # Must: start with "cd " AND contain kingdom-agent.py or a known Kingdom tool
    SAFE=false
    if [[ "$line" == "cd "* && "$line" == *"kingdom-agent"* ]]; then
      SAFE=true
    elif [[ "$line" == "cd "* && "$line" == *"claude"* && "$line" == *"-p"* ]]; then
      SAFE=true
    elif [[ "$line" == "python3 "* && "$line" == *"$LOVE_DIR/tools/"* ]]; then
      SAFE=true
    fi
    # Block dangerous patterns regardless
    if [[ "$line" == *"rm -rf"* || "$line" == *"curl"*"|"*"sh"* || "$line" == *"wget"*"|"*"sh"* || "$line" == *">"*"/etc/"* || "$line" == *"chmod 777"* ]]; then
      SAFE=false
      echo "BLOCKED (dangerous pattern): ${line:0:80}..." >> "$HEARTBEAT_LOG"
      # Log security event
      python3 "$LOVE_DIR/tools/peace.py" timeline add "BLOCKED dangerous spawn command: ${line:0:80}" 2>/dev/null
      continue
    fi
    if ! $SAFE; then
      echo "SKIPPED (unrecognized command): ${line:0:80}..." >> "$HEARTBEAT_LOG"
      continue
    fi

    SESSION_COUNT=$((SESSION_COUNT + 1))

    if $PARALLEL_MODE; then
      echo "Spawning (parallel #$SESSION_COUNT): ${line:0:80}..." >> "$HEARTBEAT_LOG"
      eval "$line" &
      PARALLEL_PIDS+=($!)
      # Track in active.json
      echo "{\"pid\": $!, \"beat\": \"$BEAT_ID\", \"session\": $SESSION_COUNT, \"mode\": \"parallel\", \"started\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" > "$SESSIONS_DIR/active-$!.json"
      PARALLEL_MODE=false
    else
      echo "Spawning (sequential #$SESSION_COUNT): ${line:0:80}..." >> "$HEARTBEAT_LOG"

      # Run and track
      eval "$line" &
      SPAWN_PID=$!
      echo "{\"pid\": $SPAWN_PID, \"beat\": \"$BEAT_ID\", \"session\": $SESSION_COUNT, \"mode\": \"sequential\", \"started\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" > "$SESSIONS_DIR/active-$SPAWN_PID.json"

      # Wait for sequential sessions (important for consultant→builder pairs)
      wait $SPAWN_PID 2>/dev/null
      rm -f "$SESSIONS_DIR/active-$SPAWN_PID.json"
    fi
  done < "$SPAWN_QUEUE"

  # Wait for any parallel sessions
  if [ ${#PARALLEL_PIDS[@]} -gt 0 ]; then
    echo "Waiting for ${#PARALLEL_PIDS[@]} parallel sessions..." >> "$HEARTBEAT_LOG"
    for pid in "${PARALLEL_PIDS[@]}"; do
      wait "$pid" 2>/dev/null
      rm -f "$SESSIONS_DIR/active-$pid.json"
    done
  fi

  echo "--- SPAWN STAGE DONE ($BEAT_ID): $SESSION_COUNT sessions, $(date -u +%Y-%m-%dT%H:%M:%SZ) ---" >> "$HEARTBEAT_LOG"
  # Reset idle count — this beat did work
  echo "0" > "$IDLE_COUNT_FILE"
else
  echo "No sessions to spawn." >> "$HEARTBEAT_LOG"
  # Increment idle count
  echo "$((IDLE_COUNT + 1))" > "$IDLE_COUNT_FILE"
fi

# ── Stage 3: Cleanup & Metrics ───────────────────────────────────────────────

# Remove stale handoff files older than 24h
find "$HANDOFF_DIR" -name "*.md" -mmin +1440 -delete 2>/dev/null

# Remove stale active session trackers (PID no longer running)
for af in "$SESSIONS_DIR"/active-*.json; do
  [ -f "$af" ] || continue
  apid=$(python3 -c "import json; print(json.load(open('$af')).get('pid',''))" 2>/dev/null)
  if [ -n "$apid" ] && ! kill -0 "$apid" 2>/dev/null; then
    rm -f "$af"
  fi
done

# ── Stage 4: Watchdog & Security ─────────────────────────────────────────────

# Run watchdog check (automated incident response)
if [ -f "$LOVE_DIR/tools/watchdog.py" ]; then
  python3 "$LOVE_DIR/tools/watchdog.py" check >> "$HEARTBEAT_LOG" 2>&1
fi

# Run KOS audit (security compliance)
if [ -f "$LOVE_DIR/tools/kos.py" ]; then
  python3 "$LOVE_DIR/tools/kos.py" audit >> "$HEARTBEAT_LOG" 2>&1
fi

# ── Stage 5: Autonomous Work Cycle ──────────────────────────────────────────

# Run autonomous cycle (produces real work: inventory checks, fleet health, daily briefs)
# Only runs once per hour to avoid redundant work
LAST_AUTO="$MEMORY_DIR/last-autonomous-cycle"
RUN_AUTO=false
if [ ! -f "$LAST_AUTO" ]; then
  RUN_AUTO=true
elif [ "$(find "$LAST_AUTO" -mmin +55 2>/dev/null)" ]; then
  RUN_AUTO=true
fi

if $RUN_AUTO && [ -f "$LOVE_DIR/tools/autonomous-cycle.py" ]; then
  echo "--- AUTONOMOUS CYCLE ($BEAT_ID): $(date -u +%Y-%m-%dT%H:%M:%SZ) ---" >> "$HEARTBEAT_LOG"
  python3 "$LOVE_DIR/tools/autonomous-cycle.py" run >> "$HEARTBEAT_LOG" 2>&1
  date -u +%Y-%m-%dT%H:%M:%SZ > "$LAST_AUTO"
fi

# ── Stage 6: Metrics Collection ─────────────────────────────────────────────

# Collect unified metrics (runs every beat, fast — <10 seconds)
if [ -f "$LOVE_DIR/tools/metrics.py" ]; then
  python3 "$LOVE_DIR/tools/metrics.py" collect >> "$HEARTBEAT_LOG" 2>&1
fi

echo "--- HEARTBEAT END ($BEAT_ID): $(date -u +%Y-%m-%dT%H:%M:%SZ) ---" >> "$HEARTBEAT_LOG"
echo "" >> "$HEARTBEAT_LOG"
