#!/usr/bin/env python3
"""
Routing Policy Engine — data-driven model selection based on ToK benchmarks.

Usage:
    python3 tools/routing-policy.py recommend --task reasoning
    python3 tools/routing-policy.py recommend --task code_gen_simple
    python3 tools/routing-policy.py recommend --prompt "explain why this algorithm is slow"
    python3 tools/routing-policy.py list
    python3 tools/routing-policy.py info --model deepseek-r1:14b
"""

import argparse
import json
import sys
from pathlib import Path


BENCHMARKS_PATH = Path(__file__).parent.parent / "memory/sessions/handoff/routing-benchmarks.json"

TASK_TYPES = [
    "code_gen_simple",
    "code_gen_complex",
    "reasoning",
    "summarization",
    "structured_output",
    "frontier",
    "quick_check",
]

KEYWORD_MAP = {
    "code_gen_simple": [
        "write a function", "implement", "create a function", "snippet", "write code",
        "simple function", "helper", "add method", "define class", "write script",
    ],
    "code_gen_complex": [
        "refactor", "architect", "redesign", "system design", "large codebase",
        "complex code", "overhaul", "restructure", "pipeline", "framework",
        "multi-file", "modular", "dependency", "integration",
    ],
    "reasoning": [
        "analyze", "explain why", "why does", "how does", "reason", "logic",
        "deduce", "infer", "evaluate", "compare", "trade-off", "tradeoff",
        "think through", "walk me through", "pros and cons", "should i",
    ],
    "summarization": [
        "summarize", "summary", "tldr", "brief", "overview", "recap",
        "key points", "main points", "digest", "condense",
    ],
    "structured_output": [
        "json", "yaml", "toml", "parse", "extract", "schema", "table",
        "structured", "format as", "output format", "csv", "serialize",
    ],
    "frontier": [
        "novel", "research", "unprecedented", "advanced", "cutting edge",
        "state of the art", "explore", "hypothesize", "creative solution",
        "never done before",
    ],
    "quick_check": [
        "check", "verify", "lint", "is this correct", "confirm", "review this line",
        "typo", "syntax error", "quick", "fast check", "does this look right",
    ],
}


def load_benchmarks() -> dict:
    if not BENCHMARKS_PATH.exists():
        print(f"ERROR: benchmarks not found at {BENCHMARKS_PATH}", file=sys.stderr)
        sys.exit(1)
    with open(BENCHMARKS_PATH) as f:
        return json.load(f)


def classify_task(prompt: str) -> str:
    """Map prompt keywords to a task type. Returns best match or 'reasoning' as default."""
    prompt_lower = prompt.lower()
    scores = {task: 0 for task in TASK_TYPES}
    for task, keywords in KEYWORD_MAP.items():
        for kw in keywords:
            if kw in prompt_lower:
                scores[task] += 1
    best = max(scores, key=lambda t: scores[t])
    if scores[best] == 0:
        return "reasoning"  # sensible default
    return best


def resolve_model_for_task(task_type: str, rules: dict, budget: dict) -> tuple[str, str | None]:
    """Return (default_model, fallback_model) for the given task type, respecting budget."""
    overrides = rules.get("overrides", {})
    fallback_chain = rules.get("fallback_chain", [])
    prefer_local = budget.get("prefer_local", True)

    if task_type in overrides:
        override = overrides[task_type]
        default = override["default"]
        fallback = override.get("fallback")
    else:
        default = rules.get("default", fallback_chain[0] if fallback_chain else "unknown")
        # fallback = next model in fallback_chain after default
        if default in fallback_chain:
            idx = fallback_chain.index(default)
            fallback = fallback_chain[idx + 1] if idx + 1 < len(fallback_chain) else None
        else:
            fallback = fallback_chain[0] if fallback_chain else None

    return default, fallback


def cmd_recommend(task_type: str | None, prompt: str | None, verbose: bool = False) -> dict:
    data = load_benchmarks()
    rules = data.get("routing_rules", {})
    models = data.get("models", {})
    budget = rules.get("budget", {})

    # Resolve task type
    if task_type is None and prompt:
        task_type = classify_task(prompt)
        classified = True
    else:
        classified = False

    if task_type not in TASK_TYPES:
        print(f"ERROR: unknown task_type '{task_type}'. Known: {TASK_TYPES}", file=sys.stderr)
        sys.exit(1)

    recommended, fallback_name = resolve_model_for_task(task_type, rules, budget)
    model_info = models.get(recommended, {})
    task_profile = model_info.get("task_profiles", {}).get(task_type, {})

    result = {
        "task_type": task_type,
        "classified_from_prompt": classified,
        "recommended": recommended,
        "model_type": model_info.get("type", "unknown"),
        "cost_per_1k_tokens": model_info.get("cost_per_1k_tokens"),
        "avg_seconds": task_profile.get("avg_seconds"),
        "success_rate": task_profile.get("success_rate"),
        "sample_size": task_profile.get("sample_size"),
        "model_notes": model_info.get("notes", ""),
        "budget": {
            "prefer_local": budget.get("prefer_local", True),
            "daily_api_limit_usd": budget.get("daily_api_limit_usd"),
            "timeout_threshold_seconds": budget.get("timeout_threshold_seconds"),
        },
    }

    if fallback_name:
        fallback_info = models.get(fallback_name, {})
        fallback_profile = fallback_info.get("task_profiles", {}).get(task_type, {})
        result["fallback"] = {
            "model": fallback_name,
            "avg_seconds": fallback_profile.get("avg_seconds"),
            "success_rate": fallback_profile.get("success_rate"),
            "escalate_on_timeout": budget.get("escalate_on_timeout", False),
        }

    if verbose:
        print(json.dumps(result, indent=2))
    else:
        lat = f"{result['avg_seconds']}s" if result["avg_seconds"] is not None else "N/A"
        sr = f"{result['success_rate']:.0%}" if result["success_rate"] is not None else "N/A"
        cost = f"${result['cost_per_1k_tokens']:.4f}/1k" if result["cost_per_1k_tokens"] else "free (local)"
        if classified:
            print(f"classified:  {task_type} (from prompt)")
        print(f"model:       {recommended}")
        print(f"type:        {result['model_type']}")
        print(f"cost:        {cost}")
        print(f"avg_latency: {lat}")
        print(f"success:     {sr}")
        if "fallback" in result:
            fb = result["fallback"]
            fb_lat = f"{fb['avg_seconds']}s" if fb["avg_seconds"] is not None else "N/A"
            timeout = result["budget"].get("timeout_threshold_seconds", "?")
            print(f"fallback:    {fb['model']} ({fb_lat}, escalate after {timeout}s)")

    return result


def cmd_list() -> None:
    data = load_benchmarks()
    rules = data.get("routing_rules", {})
    models = data.get("models", {})
    budget = rules.get("budget", {})

    print(f"{'TASK TYPE':<22} {'DEFAULT MODEL':<25} {'SUCCESS':<9} {'AVG LATENCY'}")
    print("-" * 75)
    for task in TASK_TYPES:
        model_name, _ = resolve_model_for_task(task, rules, budget)
        model_info = models.get(model_name, {})
        profile = model_info.get("task_profiles", {}).get(task, {})
        sr = f"{profile['success_rate']:.0%}" if profile.get("success_rate") is not None else "N/A"
        lat = f"{profile['avg_seconds']}s" if profile.get("avg_seconds") is not None else "N/A"
        print(f"{task:<22} {model_name:<25} {sr:<9} {lat}")


def cmd_info(model_name: str) -> None:
    data = load_benchmarks()
    models = data.get("models", {})

    if model_name not in models:
        known = list(models.keys())
        print(f"ERROR: model '{model_name}' not found. Known: {known}", file=sys.stderr)
        sys.exit(1)

    info = models[model_name]
    print(json.dumps({model_name: info}, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Routing Policy Engine — data-driven model selection")
    subparsers = parser.add_subparsers(dest="command", required=True)

    rec = subparsers.add_parser("recommend", help="Recommend model for a task type")
    rec_group = rec.add_mutually_exclusive_group()
    rec_group.add_argument(
        "--task",
        choices=TASK_TYPES,
        help=f"Task type: {', '.join(TASK_TYPES)}",
    )
    rec_group.add_argument(
        "--prompt",
        help="Auto-classify task type from prompt text",
    )
    rec.add_argument("--json", action="store_true", help="Output as JSON")

    subparsers.add_parser("list", help="List all routing rules")

    info = subparsers.add_parser("info", help="Show full model info")
    info.add_argument("--model", required=True, help="Model name")

    args = parser.parse_args()

    if args.command == "recommend":
        if args.task is None and args.prompt is None:
            rec.error("provide --task or --prompt")
        cmd_recommend(args.task, getattr(args, "prompt", None), verbose=args.json)
    elif args.command == "list":
        cmd_list()
    elif args.command == "info":
        cmd_info(args.model)


if __name__ == "__main__":
    main()
