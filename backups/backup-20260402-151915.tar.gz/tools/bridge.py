#!/usr/bin/env python3
"""
bridge.py — Kingdom Domain Bridge

Connects Kingdom systems so they compound each other.
When domains are bridged, new capabilities emerge that neither had alone.

The Vav (ו) in the Aleph — the connector between upper and lower worlds.

Bridges:
  Security × Revenue    → Risk-aware financial decisions
  Knowledge × Oracle    → Evidence-backed predictions
  Fleet × Agents        → Distributed agent workforce
  Treasury × Alignment  → Mission-weighted spending
  HIVE × Heartbeat      → Coordinated autonomous action
  PEACE × Arena         → Gamified resilience
  Metrics × Reflection  → Self-improving system

Usage:
    bridge.py map                   Show all bridges and their status
    bridge.py run <bridge-name>     Execute a bridge (cross-domain synthesis)
    bridge.py run all               Execute all bridges
    bridge.py suggest               Suggest new bridges from existing domains
    bridge.py health                Bridge health (are connections alive?)
"""

import json
import os
import sys
import subprocess
from datetime import datetime, timezone
from pathlib import Path

LOVE = Path(os.environ.get("LOVE_DIR", Path.home() / "Desktop" / "Love"))
BRIDGE_DIR = LOVE / "memory" / "bridges"

GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"
BOLD = "\033[1m"
DIM = "\033[2m"
NC = "\033[0m"


def load_json(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default if default is not None else {}


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def run_cmd(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout, cwd=str(LOVE))
        return r.returncode == 0, r.stdout.strip()
    except Exception:
        return False, ""


# ── BRIDGE DEFINITIONS ───────────────────────────────────────────────────────

BRIDGES = {
    "security-revenue": {
        "name": "Security × Revenue",
        "domains": ["security", "revenue"],
        "tools": ["tools/kos.py", "tools/treasury.py"],
        "emergent": "Risk-aware financial decisions. Security posture informs spend confidence.",
        "action": "security_revenue_bridge",
    },
    "knowledge-oracle": {
        "name": "Knowledge × Oracle",
        "domains": ["knowledge", "predictions"],
        "tools": ["tools/knowledge.py", "tools/oracle.py"],
        "emergent": "Evidence-backed predictions. Knowledge graph feeds prediction research.",
        "action": "knowledge_oracle_bridge",
    },
    "fleet-agents": {
        "name": "Fleet × Agents",
        "domains": ["infrastructure", "agents"],
        "tools": ["tools/fleet.py", "tools/citizens.py", "tools/kingdom-agent.py"],
        "emergent": "Distributed agent workforce. Any agent runs on any node.",
        "action": "fleet_agents_bridge",
    },
    "treasury-alignment": {
        "name": "Treasury × Alignment",
        "domains": ["revenue", "mandate"],
        "tools": ["tools/treasury.py", "tools/alignment.py"],
        "emergent": "Mission-weighted spending. Every pound evaluated against the mandate.",
        "action": "treasury_alignment_bridge",
    },
    "peace-arena": {
        "name": "PEACE × Arena",
        "domains": ["security", "zerone"],
        "tools": ["tools/peace.py", "tools/arena.py", "tools/zerone-bridge.py"],
        "emergent": "Gamified resilience. Security testing earns ZRN. The game IS the work.",
        "action": "peace_arena_bridge",
    },
    "metrics-reflection": {
        "name": "Metrics × Reflection",
        "domains": ["observability", "self-improvement"],
        "tools": ["tools/metrics.py", "tools/reflect.py"],
        "emergent": "Self-improving system. Metrics feed reflection. Reflection produces proposals.",
        "action": "metrics_reflection_bridge",
    },
    "hive-heartbeat": {
        "name": "HIVE × Heartbeat",
        "domains": ["communication", "autonomy"],
        "tools": ["tools/hive-protocol.py", "tools/heartbeat-runner.sh"],
        "emergent": "Coordinated autonomous action. Structured messages drive agent decisions.",
        "action": "hive_heartbeat_bridge",
    },
    "tcg-oracle": {
        "name": "TCG × Oracle",
        "domains": ["revenue", "predictions"],
        "tools": ["tools/tcg.py", "tools/oracle.py"],
        "emergent": "Market-intelligent commerce. Oracle predictions inform TCG purchasing decisions.",
        "action": "tcg_oracle_bridge",
    },
    "watchdog-crucible": {
        "name": "Watchdog × Crucible",
        "domains": ["monitoring", "testing"],
        "tools": ["tools/watchdog.py", "instances/crucible/HEARTBEAT.md"],
        "emergent": "Continuous adversarial monitoring. Crucible hunts what watchdog guards.",
        "action": "watchdog_crucible_bridge",
    },
    "zerone-knowledge": {
        "name": "Zerone × Knowledge",
        "domains": ["blockchain", "knowledge"],
        "tools": ["tools/zerone-bridge.py", "tools/knowledge.py", "tools/tok.py"],
        "emergent": "On-chain knowledge. ToK-verified insights become Proof-of-Truth claims.",
        "action": "zerone_knowledge_bridge",
    },
}


def check_bridge_health(bridge):
    """Check if both sides of a bridge are operational."""
    tools = bridge.get("tools", [])
    alive = 0
    for tool in tools:
        if (LOVE / tool).exists():
            alive += 1
    return alive, len(tools)


# ── BRIDGE ACTIONS ───────────────────────────────────────────────────────────
# Each bridge action synthesizes data from both domains

def security_revenue_bridge():
    """Cross-reference security posture with financial health."""
    results = []

    # Read PEACE score
    peace = load_json(LOVE / "security" / "peace-state.json")
    score = peace.get("score", 0)

    # Read treasury
    treasury_engines = load_json(LOVE / "memory" / "treasury" / "engines.json", [])

    results.append(f"PEACE score: {score}%")

    if score >= 90:
        results.append(f"{GREEN}High resilience → safe to invest in growth engines{NC}")
    elif score >= 70:
        results.append(f"{YELLOW}Moderate resilience → invest cautiously, shore up defenses{NC}")
    else:
        results.append(f"{RED}Low resilience → prioritize security before revenue expansion{NC}")

    # Check which engines are at risk
    threats = load_json(LOVE / "security" / "threat-model.json")
    threat_list = threats.get("threats", [])
    revenue_threats = [t for t in threat_list if not t.get("mitigated")
                       and t.get("category") in ("supply-chain", "access")]
    if revenue_threats:
        results.append(f"{YELLOW}{len(revenue_threats)} unmitigated threats to revenue:{NC}")
        for t in revenue_threats[:3]:
            results.append(f"  {DIM}{t.get('name', '?')}{NC}")

    return results


def knowledge_oracle_bridge():
    """Feed knowledge graph insights into Oracle predictions."""
    results = []

    insights = load_json(LOVE / "memory" / "knowledge" / "insights.json", [])
    predictions = load_json(LOVE / "memory" / "oracle" / "predictions.json", [])
    pending = [p for p in predictions if not p.get("resolved")]

    results.append(f"Knowledge: {len(insights)} insights available")
    results.append(f"Oracle: {len(pending)} predictions pending resolution")

    # Find insights that could inform predictions
    for pred in pending:
        stmt = pred.get("statement", "").lower()
        relevant = [i for i in insights if any(
            word in i.get("content", "").lower()
            for word in stmt.split() if len(word) > 4
        )]
        if relevant:
            results.append(f"{GREEN}Insight match for {pred.get('id', '?')}: {len(relevant)} relevant insight(s){NC}")

    if not pending:
        results.append(f"{YELLOW}No pending predictions to cross-reference{NC}")

    return results


def fleet_agents_bridge():
    """Map agent deployment readiness to fleet capacity."""
    results = []

    cfg = load_json(LOVE / "love.json")
    instances = cfg.get("instances", {})
    fleet = cfg.get("fleet", {})

    agents_need_device = []
    for name, info in instances.items():
        if not info.get("device"):
            agents_need_device.append(name)

    results.append(f"Fleet: {len(fleet)} VPS nodes available")
    results.append(f"Agents: {len(instances)} total, {len(agents_need_device)} need device assignment")

    if agents_need_device and fleet:
        results.append(f"{GREEN}BRIDGE: {len(agents_need_device)} agents can deploy to {len(fleet)} fleet nodes via kingdom-agent{NC}")
        results.append(f"  Run: bash tools/fleet-agent-deploy.sh")
    else:
        results.append(f"{DIM}All agents have device assignments or no fleet available{NC}")

    return results


def treasury_alignment_bridge():
    """Weight financial decisions against the mandate."""
    results = []

    # Read engine financials
    engines = load_json(LOVE / "memory" / "treasury" / "engines.json", [])
    if isinstance(engines, list):
        engine_list = engines
    elif isinstance(engines, dict):
        engine_list = list(engines.values()) if not isinstance(list(engines.values())[0] if engines else None, dict) else [v for v in engines.values()]
    else:
        engine_list = []

    alignment_scores = {
        "cambridge_tcg": ("high", "Funds the mission directly"),
        "oracle": ("high", "Truth-seeking through prediction"),
        "zerone": ("very-high", "IS the mandate's infrastructure"),
        "ai_services": ("high", "Capability shared outward"),
        "seigei": ("medium", "Needs careful positioning"),
        "shopify_apps": ("medium", "Generic commerce"),
    }

    results.append(f"{BOLD}Revenue engines × Mandate alignment:{NC}")
    for name, (level, reason) in alignment_scores.items():
        color = GREEN if level in ("high", "very-high") else YELLOW
        results.append(f"  {color}{level:10s}{NC} {name:20s} {DIM}{reason}{NC}")

    results.append(f"\n{MAGENTA}Mandate priority: Invest in high-alignment engines first.{NC}")
    results.append(f"{MAGENTA}Zerone > Cambridge TCG > Oracle > AI Services > Seigei > Shopify{NC}")

    return results


def peace_arena_bridge():
    """Connect PEACE drills to Arena challenges and ZRN rewards."""
    results = []

    peace = load_json(LOVE / "security" / "peace-state.json")
    claims = load_json(LOVE / "memory" / "zerone-bridge" / "claims.json", [])

    results.append(f"PEACE state: {peace.get('state', peace.get('status', '?'))}")
    results.append(f"ZRN claims: {len(claims)} ({sum(c.get('zrn', 0) for c in claims)} ZRN)")

    # Every PEACE drill should generate an Arena challenge
    results.append(f"\n{GREEN}BRIDGE: PEACE drills → Arena challenges → ZRN rewards{NC}")
    results.append(f"  Every security test that passes = defense proof = ZRN earned")
    results.append(f"  Every vulnerability found = security finding = ZRN earned")
    results.append(f"  The game IS the useful work. Proof of Truth.")

    return results


def metrics_reflection_bridge():
    """Feed metrics trends into reflection proposals."""
    results = []

    # Check if metrics exist
    latest = load_json(LOVE / "memory" / "metrics" / "latest.json")
    loop_state = load_json(LOVE / "memory" / "loop" / "loop-state.json")

    proposals = loop_state.get("pending_proposals", 0)
    last_reflect = loop_state.get("last_reflect", "never")

    results.append(f"Last reflection: {str(last_reflect)[:16]}")
    results.append(f"Pending proposals: {proposals}")

    if latest:
        results.append(f"{GREEN}Metrics → Reflection pipeline active{NC}")
    else:
        results.append(f"{YELLOW}No metrics collected yet. Run: metrics.py collect{NC}")

    results.append(f"\n{GREEN}BRIDGE: metrics.py collect → reflect.py sense → proposals{NC}")
    results.append(f"  Metrics detect trends. Reflection interprets them. Proposals fix drift.")

    return results


def hive_heartbeat_bridge():
    """Show how HIVE messages drive heartbeat decisions."""
    results = []

    results.append(f"Heartbeat: every 7 minutes via heartbeat-runner.sh")
    results.append(f"HIVE protocol: structured task/alert/insight messages")
    results.append(f"\n{GREEN}BRIDGE: HIVE tasks → Heartbeat spawn decisions{NC}")
    results.append(f"  hive-protocol.py task create → coordinator reads → spawns builder")
    results.append(f"  hive-protocol.py broadcast alert → watchdog detects → escalates")
    results.append(f"  Structured messages enable autonomous coordination")

    return results


def tcg_oracle_bridge():
    results = [f"{GREEN}BRIDGE: Oracle market predictions → TCG purchasing decisions{NC}"]
    results.append(f"  Oracle tracks macro trends. TCG uses them for inventory timing.")
    results.append(f"  When Oracle detects market shift → TCG adjusts purchasing strategy")
    return results


def watchdog_crucible_bridge():
    results = [f"{GREEN}BRIDGE: Watchdog monitors → Crucible probes{NC}"]
    results.append(f"  Watchdog: passive monitoring every 5 minutes")
    results.append(f"  Crucible: active testing on 7-day rotation")
    results.append(f"  Together: continuous + adversarial = defense in depth")
    return results


def zerone_knowledge_bridge():
    results = [f"{GREEN}BRIDGE: ToK pipeline → Knowledge graph → Zerone PoT claims{NC}"]
    results.append(f"  ToK harvests knowledge. Knowledge graph structures it.")
    results.append(f"  Zerone bridge converts verified knowledge into on-chain truth.")
    results.append(f"  {MAGENTA}Knowledge verification IS the useful work.{NC}")
    return results


BRIDGE_ACTIONS = {
    "security-revenue": security_revenue_bridge,
    "knowledge-oracle": knowledge_oracle_bridge,
    "fleet-agents": fleet_agents_bridge,
    "treasury-alignment": treasury_alignment_bridge,
    "peace-arena": peace_arena_bridge,
    "metrics-reflection": metrics_reflection_bridge,
    "hive-heartbeat": hive_heartbeat_bridge,
    "tcg-oracle": tcg_oracle_bridge,
    "watchdog-crucible": watchdog_crucible_bridge,
    "zerone-knowledge": zerone_knowledge_bridge,
}


# ── COMMANDS ─────────────────────────────────────────────────────────────────

def cmd_map():
    """Show all bridges."""
    print(f"\n{BOLD}  Kingdom Domain Bridges{NC}")
    print(f"  {DIM}The Vav — connecting upper and lower worlds{NC}\n")

    for bid, bridge in BRIDGES.items():
        alive, total = check_bridge_health(bridge)
        if alive == total:
            status = f"{GREEN}CONNECTED{NC}"
        elif alive > 0:
            status = f"{YELLOW}PARTIAL{NC}"
        else:
            status = f"{RED}BROKEN{NC}"

        print(f"  {status:30s} {BOLD}{bridge['name']}{NC}")
        print(f"  {'':30s} {DIM}{bridge['emergent']}{NC}")
        print()


def cmd_run(bridge_name):
    """Execute a bridge."""
    if bridge_name == "all":
        for bid in BRIDGES:
            cmd_run(bid)
        return

    if bridge_name not in BRIDGES:
        print(f"  Unknown bridge: {bridge_name}")
        print(f"  Available: {', '.join(BRIDGES.keys())}")
        return

    bridge = BRIDGES[bridge_name]
    action_fn = BRIDGE_ACTIONS.get(bridge_name)

    print(f"\n  {BOLD}{bridge['name']}{NC}")
    print(f"  {DIM}{'─' * 50}{NC}")

    if action_fn:
        results = action_fn()
        for r in results:
            print(f"  {r}")
    else:
        print(f"  {DIM}No action defined for this bridge.{NC}")

    print()


def cmd_suggest():
    """Suggest new bridges from existing domains."""
    print(f"\n{BOLD}  Emerging Bridge Opportunities{NC}\n")

    suggestions = [
        {
            "bridge": "Backup × Fleet Tasks",
            "emergent": "Distributed backup verification. Fleet nodes cross-verify each other's backups.",
            "prerequisite": "backup.py + fleet-tasks.py operational",
        },
        {
            "bridge": "Services × Treasury",
            "emergent": "Auto-invoicing. Service deliverables trigger treasury revenue entries.",
            "prerequisite": "services.py client delivery tracking",
        },
        {
            "bridge": "Citizens × Arena",
            "emergent": "Agent skill trees. Arena victories unlock agent capabilities and rank promotions.",
            "prerequisite": "arena.py challenges with agent-specific tracks",
        },
        {
            "bridge": "Oracle × Zerone",
            "emergent": "On-chain prediction markets. Oracle predictions become Zerone smart contracts.",
            "prerequisite": "Zerone testnet with smart contract support",
        },
        {
            "bridge": "Alignment × Reflection",
            "emergent": "Mandate-aware self-improvement. Reflection proposals scored against alignment dimensions.",
            "prerequisite": "alignment.py scoring in reflect.py propose output",
        },
    ]

    for s in suggestions:
        print(f"  {CYAN}{BOLD}{s['bridge']}{NC}")
        print(f"    Emergent: {s['emergent']}")
        print(f"    Needs:    {DIM}{s['prerequisite']}{NC}")
        print()


def cmd_health():
    """Check bridge health."""
    print(f"\n{BOLD}  Bridge Health{NC}\n")

    total_alive = 0
    total_endpoints = 0

    for bid, bridge in BRIDGES.items():
        alive, total = check_bridge_health(bridge)
        total_alive += alive
        total_endpoints += total

        if alive == total:
            icon = f"{GREEN}●{NC}"
        elif alive > 0:
            icon = f"{YELLOW}◐{NC}"
        else:
            icon = f"{RED}○{NC}"

        print(f"  {icon} {bridge['name']:30s} {alive}/{total} endpoints")

    pct = total_alive / total_endpoints * 100 if total_endpoints else 0
    color = GREEN if pct >= 80 else YELLOW if pct >= 60 else RED
    print(f"\n  {BOLD}Overall: {color}{pct:.0f}%{NC} ({total_alive}/{total_endpoints} endpoints connected)\n")


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "map"
    if cmd == "map":
        cmd_map()
    elif cmd == "run":
        target = sys.argv[2] if len(sys.argv) > 2 else "all"
        cmd_run(target)
    elif cmd == "suggest":
        cmd_suggest()
    elif cmd == "health":
        cmd_health()
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
