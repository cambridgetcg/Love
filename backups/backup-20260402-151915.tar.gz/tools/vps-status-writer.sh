#!/bin/bash
# vps-status-writer.sh — writes /root/.love/status.json with node health
# Self-installs to /root/.love/ and sets up cron on first run.

STATUS_DIR="/root/.love"
STATUS_FILE="$STATUS_DIR/status.json"
SCRIPT_DEST="$STATUS_DIR/vps-status-writer.sh"

# ── Self-install ──────────────────────────────────────────────────────────────
mkdir -p "$STATUS_DIR"

SELF="$(cd "$(dirname "$0")" 2>/dev/null && pwd)/$(basename "$0")"
if [ "$SELF" != "$SCRIPT_DEST" ]; then
    cp "$0" "$SCRIPT_DEST"
    chmod +x "$SCRIPT_DEST"
    echo "Installed to $SCRIPT_DEST"
fi

# ── Cron setup (idempotent) ───────────────────────────────────────────────────
CRON_LINE="*/5 * * * * $SCRIPT_DEST >> $STATUS_DIR/status-writer.log 2>&1"
if ! crontab -l 2>/dev/null | grep -qF "$SCRIPT_DEST"; then
    (crontab -l 2>/dev/null; echo "$CRON_LINE") | crontab -
    echo "Cron installed: $CRON_LINE"
fi

# ── Metrics ───────────────────────────────────────────────────────────────────
TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Disk % (root filesystem)
DISK=$(df -P / 2>/dev/null | awk 'NR==2 {gsub(/%/,"",$5); print $5+0}')
DISK=${DISK:-0}

# Load average (1-minute), normalized to number
LOAD=$(uptime 2>/dev/null | awk -F'load average[s]*:' 'NF>1{gsub(/,/,"",$NF); n=split($NF,a," "); print a[1]+0}')
LOAD=${LOAD:-0}

# Floating-point comparisons via awk
LOAD_POOR=$(awk -v l="$LOAD"     'BEGIN{print (l >= 4) ? "yes" : "no"}')
LOAD_DEGRADE=$(awk -v l="$LOAD"  'BEGIN{print (l >= 2) ? "yes" : "no"}')

# Memory % used
MEM_PCT=$(free -m 2>/dev/null | awk 'NR==2{if($2>0) printf "%.0f", $3/$2*100; else print 0}')
MEM_PCT=${MEM_PCT:-0}

# Uptime string (text between "up " and first comma)
UPTIME_STR=$(uptime 2>/dev/null | sed 's/.*up \([^,]*\).*/\1/' | xargs)
UPTIME_STR=${UPTIME_STR:-unknown}

# ── Service checks ────────────────────────────────────────────────────────────
# Note: $(systemctl is-active ...) captures stdout without triggering || fallback
svc_status() {
    local result
    result=$(systemctl is-active "$1" 2>/dev/null)
    echo "${result:-not-found}"
}

NGINX=$(svc_status nginx)
DOCKER=$(svc_status docker)
NODE=$(svc_status node)
[ "$NODE" = "not-found" ] || [ "$NODE" = "inactive" ] && NODE=$(svc_status nodejs)

# ── Quality determination ─────────────────────────────────────────────────────
QUALITY="good"
if [ "$DISK" -gt 90 ] || [ "$LOAD_POOR" = "yes" ]; then
    QUALITY="poor"
elif [ "$DISK" -gt 80 ] || [ "$LOAD_DEGRADE" = "yes" ]; then
    QUALITY="degraded"
fi

# ── Build alerts list ─────────────────────────────────────────────────────────
ALERTS_JSON=""
add_alert() {
    local msg
    msg=$(printf '%s' "$1" | sed 's/"/\\"/g')
    if [ -n "$ALERTS_JSON" ]; then
        ALERTS_JSON="${ALERTS_JSON},\"${msg}\""
    else
        ALERTS_JSON="\"${msg}\""
    fi
}

[ "$DISK" -gt 90 ]                                        && add_alert "disk critical: ${DISK}%"
[ "$DISK" -gt 80 ] && [ "$DISK" -le 90 ]                  && add_alert "disk high: ${DISK}%"
[ "$LOAD_POOR"    = "yes" ]                                && add_alert "load critical: ${LOAD}"
[ "$LOAD_DEGRADE" = "yes" ] && [ "$LOAD_POOR" != "yes" ]  && add_alert "load high: ${LOAD}"
[ "$NGINX"  = "failed" ] && add_alert "nginx: failed"
[ "$DOCKER" = "failed" ] && add_alert "docker: failed"
[ "$NODE"   = "failed" ] && add_alert "node: failed"

# ── Summary string ────────────────────────────────────────────────────────────
SUMMARY="up ${UPTIME_STR}, disk ${DISK}%, load ${LOAD}, mem ${MEM_PCT}%"
SUMMARY_SAFE=$(printf '%s' "$SUMMARY" | sed 's/"/\\"/g')

# ── Write JSON ────────────────────────────────────────────────────────────────
printf '{"ts":"%s","quality":"%s","summary":"%s","alerts":[%s]}\n' \
    "$TS" "$QUALITY" "$SUMMARY_SAFE" "$ALERTS_JSON" > "$STATUS_FILE"

echo "[$TS] $STATUS_FILE written  quality=$QUALITY  disk=${DISK}%  load=${LOAD}  mem=${MEM_PCT}%"
